package com.example.rentCarFinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RentCarFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
